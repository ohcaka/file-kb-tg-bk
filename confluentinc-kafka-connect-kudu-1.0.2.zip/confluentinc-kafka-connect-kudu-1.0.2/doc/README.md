# Introduction

This project provides connectors for Kafka Connect to read and write data to Kudu.

# Documentation

Documentation on the connector is hosted on Confluent's
[docs site](https://docs.confluent.io/current/connect/kafka-connect-kudu/).

Source code is located in Confluent's
[docs repo](https://github.com/confluentinc/docs/tree/master/connect/kafka-connect-kudu). If changes
are made to configuration options for the connector, be sure to generate the RST docs (as described
below) and open a PR against the docs repo to publish those changes!

# Configs

Documentation on the configurations for each connector can be automatically generated via Maven.

To generate documentation for the sink connector:
```bash
mvn -Pdocs exec:java@sink-config-docs
```

To generate documentation for the source connector:
```bash
mvn -Pdocs exec:java@source-config-docs
```

# Compatibility Matrix:

This connector has been tested against the following versions of Apache Kafka
and Kudu:

|                          | AK 1.0             | AK 1.1        | AK 2.0        |
| ------------------------ | ------------------ | ------------- | ------------- |
| **Kudu v1.2.3** | NOT COMPATIBLE (1) | OK            | OK            |

1. The connector needs header support in Connect.

# Running Integration Tests Locally

Integration tests can be setup locally by setting docker images. Since impala uses a large amount of memory increase the memory allocated to docker to about 5 or 6 GB.

- Start kudu docker container by following https://kudu.apache.org/docs/quickstart.html
- Start impala docker by following https://github.com/apache/kudu/tree/master/examples/quickstart/impala#run-apache-impala
- Set `USERNAME` and `PASSWORD` to "" in io.confluent.connect.kudu.integration.TestConstants
- Impala doesn't support create tables via jdbc driver  without authentication due to https://issues.apache.org/jira/browse/IMPALA-9486
  As a workaround, we need to pre-create the tables via impala shell (https://github.com/apache/kudu/tree/master/examples/quickstart/impala#run-the-impala-shell)
  
```bash
docker exec -it kudu-impala impala-shell
```  
```
CREATE TABLE `json_topic` (
`__connect_topic` STRING NOT NULL,
`__connect_partition` INT NOT NULL,
`__connect_offset` BIGINT NOT NULL,
`int_col` INT NOT NULL,
`timestamp_col` TIMESTAMP NOT NULL,
`time_col` TIMESTAMP NOT NULL,
`decimal_col` DECIMAL(38, 10) NOT NULL,
`date_col` TIMESTAMP NOT NULL,
PRIMARY KEY(`__connect_topic`,`__connect_partition`,`__connect_offset`)) PARTITION BY HASH PARTITIONS 2 STORED AS KUDU TBLPROPERTIES ('kudu.num_tablet_replicas' = '1');
```
```bash
CREATE TABLE `kafka_logical` (
`__connect_topic` STRING NOT NULL,
`__connect_partition` INT NOT NULL,
`__connect_offset` BIGINT NOT NULL,
`int_col` INT NOT NULL,
`timestamp_col` TIMESTAMP NOT NULL,
`time_col` TIMESTAMP NOT NULL,
`decimal_col` DECIMAL(38, 10) NOT NULL,
`date_col` TIMESTAMP NOT NULL,
PRIMARY KEY(`__connect_topic`,`__connect_partition`,`__connect_offset`)) PARTITION BY HASH PARTITIONS 2 STORED AS KUDU TBLPROPERTIES ('kudu.num_tablet_replicas' = '1');
```

```bash
CREATE TABLE `kafka_evolving` (
`__connect_topic` STRING NOT NULL,
`__connect_partition` INT NOT NULL,
`__connect_offset` BIGINT NOT NULL,
`int_col` INT NOT NULL,
`date_col` TIMESTAMP DEFAULT '1970-01-01 00:00:00.000',
PRIMARY KEY(`__connect_topic`,`__connect_partition`,`__connect_offset`)) PARTITION BY HASH PARTITIONS 2 STORED AS KUDU TBLPROPERTIES ('kudu.num_tablet_replicas' = '1');
```

```bash
CREATE TABLE `kafka1` (
`__connect_topic` STRING NOT NULL,
`__connect_partition` INT NOT NULL,
`__connect_offset` BIGINT NOT NULL,
`float_col` FLOAT NOT NULL,
`int_col` INT NOT NULL,
`long_col` BIGINT NOT NULL,
`string_col` STRING NOT NULL,
`byte_col` TINYINT NOT NULL,
`boolean_col` BOOLEAN NOT NULL,
`double_col` DOUBLE NOT NULL,
`short_col` SMALLINT NOT NULL,
PRIMARY KEY(`__connect_topic`,`__connect_partition`,`__connect_offset`)) PARTITION BY HASH PARTITIONS 2 STORED AS KUDU TBLPROPERTIES ('kudu.num_tablet_replicas' = '1');
```

```bash
CREATE TABLE IF NOT EXISTS source_json_topic ( int_col INT NOT NULL, decimal_col DECIMAL(38, 10) NOT NULL, timestamp_col TIMESTAMP NOT NULL, date_col TIMESTAMP NOT NULL, time_col TIMESTAMP NOT NULL, PRIMARY KEY( int_col ) ) PARTITION BY HASH PARTITIONS 2 STORED AS KUDU TBLPROPERTIES ('kudu.num_tablet_replicas' = '1');
```
