/*
 * Copyright 2018 Confluent Inc.
 *
 * Licensed under the Confluent Community License (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a copy of the
 * License at
 *
 * http://www.confluent.io/confluent-community-license
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OF ANY KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations under the License.
 */

package io.confluent.connect.jdbc.sink;

import org.apache.kafka.common.header.Header;

/** Header for the error records to be written to dead-letter-queue topic.
 * The header includes the Kafka coordinates of the original record as key and
 * and context of the failure(error message) as value of the header.
 */
public class DlqMessageHeader implements Header {

  private String errorMessage;
  private String topic;
  private long partition;
  private long offset;

  public DlqMessageHeader(String errorMessage, String topic, long partition, long offset) {
    this.errorMessage = errorMessage;
    this.topic = topic;
    this. partition = partition;
    this.offset = offset;
  }

  @Override
  public String key() {
    return "{"
        + ", topic='" + topic + '\''
        + ", partition=" + partition
        + ", offset=" + offset
        + '}';
  }

  @Override
  public byte[] value() {
    return errorMessage.getBytes();
  }

  @Override
  public String toString() {
    return "{"
        + "errorMessage='" + errorMessage + '\''
        + ", topic='" + topic + '\''
        + ", partition=" + partition
        + ", offset=" + offset
        + '}';
  }
}
